//
//  DemoTimeApp.swift
//  DemoTime
//
//  Created by Peter Ekler on 2023. 09. 04..
//

import SwiftUI

@main
struct DemoTimeApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    
    
}
