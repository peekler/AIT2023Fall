//
//  ContentView.swift
//  DemoTime
//
//  Created by Peter Ekler on 2023. 09. 04..
//

import SwiftUI

struct ContentView: View {
    @State private var currentTime = ""
    
    var body: some View {
        VStack {
            Text(currentTime).font(.largeTitle).padding()
            
            Button("Current time") {
                            currentTime = "Current Time: \(Date().description)"
                        }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
